using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    public Player_Movement player;
    public GameObject connected_portal;
    public bool covered = false;
    public List<int> present_levels = new List<int>();

    void Start()
    {
        transform.position = new Vector3(100, 100, 0);
    }

    public void set_position_to_beginning(int level)
    {
        if (present_levels.Contains(level))
        {
            gameObject.SetActive(true);
        }
        else
        {
            gameObject.SetActive(false);
        }
    }
}
