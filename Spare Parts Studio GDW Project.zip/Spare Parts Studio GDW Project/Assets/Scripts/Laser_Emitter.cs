using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser_Emitter : MonoBehaviour
{
    public Vector2 direction = Vector2.left;
    public GameObject laser_obj;
    public Laser laser_code;

    void Start()
    {
        laser_code = laser_obj.GetComponent<Laser>();
        laser_code.direction = this.direction;
        laser_obj.layer = this.gameObject.layer;
        Instantiate(laser_obj, this.transform);
    }

    void Update()
    {
        
    }
}
