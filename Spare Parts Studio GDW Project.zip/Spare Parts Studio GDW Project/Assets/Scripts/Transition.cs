using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Transition : MonoBehaviour
{
    public string type = "";
    public int fixed_warp;
    public List<Vector2> locations;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
