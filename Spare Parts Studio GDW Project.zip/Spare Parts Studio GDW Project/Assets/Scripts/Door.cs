using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    public List<Vector2> start_positions = new List<Vector2>();
    public List<Vector2> level_direction = new List<Vector2>();
    public SpriteRenderer door_sprite;
    public Collider2D collision;
    public List<Sprite> opened_doors;
    public List<Sprite> closed_doors;
    public GameObject player;
    public List<Box> boxes = new List<Box>();
    Vector2 direction = Vector2.zero;

    public void set_position_to_beginning(int level)
    {
        door_sprite.GetComponent<SpriteRenderer>();
        transform.position = new Vector3(start_positions[level].x, start_positions[level].y, 0);
        direction = level_direction[level];
        close();
    }

    public void open()
    {
        set_sprite("open");
        collision.isTrigger = true;
    }

    public void close()
    {
        set_sprite("close");
        collision.isTrigger = false;
        if (player.transform.position == this.transform.position)
        {
            if (direction == Vector2.up)
            {
                player.GetComponent<Player_Movement>().knockback("down");
            }
            else if (direction == Vector2.left)
            {
                player.GetComponent<Player_Movement>().knockback("right");
            }
            else if (direction == Vector2.down)
            {
                player.GetComponent<Player_Movement>().knockback("up");
            }
            else if (direction == Vector2.right)
            {
                player.GetComponent<Player_Movement>().knockback("left");
            }
        }
        for (int i = 0; boxes.Count > i; i++)
        {
            Box checked_box = boxes[i];
            if (checked_box.transform.position == this.transform.position)
            {
                if (checked_box.gameObject.layer == this.gameObject.layer)
                {
                    if (checked_box.can_be_pushed(new Vector3(direction.x * -1, direction.y * -1, 0), true))
                    {
                        checked_box.push(new Vector3(direction.x * -1, direction.y * -1, 0), player.GetComponent<Player_Movement>().movement_speed);
                    }
                }
            }
        }
    }

    public void set_sprite(string state)
    {
        if (state == "open")
        {
            if (direction == Vector2.up)
            {
                door_sprite.sprite = opened_doors[0];
            }
            else if (direction == Vector2.left)
            {
                door_sprite.sprite = opened_doors[1];
            }
            else if (direction == Vector2.down)
            {
                door_sprite.sprite = opened_doors[2];
            }
            else if (direction == Vector2.right)
            {
                door_sprite.sprite = opened_doors[3];
            }
        }
        else
        {
            if (direction == Vector2.up)
            {
                door_sprite.sprite = closed_doors[0];
            }
            else if (direction == Vector2.left)
            {
                door_sprite.sprite = closed_doors[1];
            }
            else if (direction == Vector2.down)
            {
                door_sprite.sprite = closed_doors[2];
            }
            else if (direction == Vector2.right)
            {
                door_sprite.sprite = closed_doors[3];
            }
        }
    }
}
