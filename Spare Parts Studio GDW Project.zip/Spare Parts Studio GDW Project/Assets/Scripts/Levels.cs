using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Levels : MonoBehaviour
{
    public GameObject start_warp;
    public GameObject end_warp;
    public Camera camera;
    List<Vector2> start_points = new List<Vector2>();
    List<Vector2> end_points = new List<Vector2>();
    List<float> zoom_level = new List<float>();

    void Awake()
    {
        start_points.Add(new Vector2(0, 5)); //attic 0 start coordinates
        end_points.Add(new Vector2(0, -6)); //attic 0 end coordinates
        zoom_level.Add(6.5f); //attic 0 zoom amount
        start_points.Add(new Vector2(0, 4)); //attic 1 start coordinates
        end_points.Add(new Vector2(0, -4)); //attic 1 end coordinates
        zoom_level.Add(4.8f); //attic 1 zoom amount
        start_points.Add(new Vector2(0, 5)); //attic 2 start coordinates
        end_points.Add(new Vector2(0, -5)); //attic 2 end coordinates
        zoom_level.Add(5.7f); //attic 2 zoom amount
        start_points.Add(new Vector2(0, 5)); //attic 3 start coordinates
        end_points.Add(new Vector2(0, -5)); //attic 3 end coordinates
        zoom_level.Add(6.5f); //attic 3 zoom amount
        start_points.Add(new Vector2(0, 6)); //ice 0 start coordinates
        end_points.Add(new Vector2(0, -6)); //ice 0 end coordinates
        zoom_level.Add(7.5f); //ice 0 zoom amount
        start_points.Add(new Vector2(-1, 6)); //ice 0 start coordinates
        end_points.Add(new Vector2(-1, -6)); //ice 0 end coordinates
        zoom_level.Add(7.5f); //ice 1 zoom amount
        start_points.Add(new Vector2(0, 5)); //portal 0 start coordinates
        end_points.Add(new Vector2(0, -5)); //portal 0 end coordinates
        zoom_level.Add(6.5f); //portal 0 zoom amount
    }

    public void load_level(int level)
    {
        camera.orthographicSize = zoom_level[level];
        for (int i = 1; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).gameObject.active)
            {
                transform.GetChild(i).gameObject.SetActive(false);
            }
            if (i == level + 1)
            {
                transform.GetChild(i).gameObject.SetActive(true);
            }
        }
        start_warp.transform.position = start_points[level];
        end_warp.transform.position = end_points[level];
    }
}
